import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class TestLibro {
    public static void main(String[] args) {
        // Crear una lista de libros
        ArrayList<Libro> libros = new ArrayList<>();
        libros.add(new Libro("El Principito", "Antoine de Saint-Exupéry", 1943));
        libros.add(new Libro("Cien Años de Soledad", "Gabriel García Márquez", 1967));
        libros.add(new Libro("1984", "George Orwell", 1949));

        // Generar JSON con Jackson
        ObjectMapper jsonMapper = new ObjectMapper(); // ObjectMapper de Jackson: permite leer y escribir JSON
        try {
            jsonMapper.writeValue(new File("libros.json"), libros);
        } catch (IOException ex) {
            System.out.println("Error al generar el archivo JSON.");
        }
        System.out.println("Archivo JSON generado con éxito.");

        // Cargar JSON con Jackson
        ArrayList<Libro> librosCargadosJson = null;
        try {
            librosCargadosJson = jsonMapper.readValue(new File("libros.json"), jsonMapper.getTypeFactory().constructCollectionType(ArrayList.class, Libro.class));
        } catch (IOException ex) {
            System.out.println("Error al cargar el archivo JSON.");
        }
        System.out.println("Libros cargados desde JSON:");
        if (librosCargadosJson != null) {
            for (Libro libro : librosCargadosJson) {
                System.out.println(libro);
            }
        } else {
            System.out.println("No se han cargado libros del JSON.");
        }

        // Generar YAML con Jackson
        ObjectMapper yamlMapper = new ObjectMapper(new YAMLFactory());
        try {
            yamlMapper.writeValue(new File("libros.yaml"), libros);
        } catch (IOException ex) {
            System.out.println("Error al generar el archivo YAML.");
        }
        System.out.println("Archivo YAML generado con éxito.");

        // Cargar YAML con Jackson
        ArrayList<Libro> librosCargadosYaml = null;
        try {
            librosCargadosYaml = yamlMapper.readValue(new File("libros.yaml"), jsonMapper.getTypeFactory().constructCollectionType(ArrayList.class, Libro.class));
        } catch (IOException ex) {
            System.out.println("Error al cargar el archivo YAML.");
        }
        System.out.println("Libros cargados desde YAML:");
        if (librosCargadosYaml != null) {
            for (Libro libro : librosCargadosYaml) {
                System.out.println(libro);
            }
        } else {
            System.out.println("No se han cargado libros del YAML.");
        }
    }
}
